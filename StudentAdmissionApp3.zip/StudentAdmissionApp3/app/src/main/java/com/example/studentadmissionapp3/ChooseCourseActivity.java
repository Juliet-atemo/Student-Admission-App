package com.example.studentadmissionapp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ChooseCourseActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_course);

        radioGroup = findViewById(R.id.radioGroupCourses);
        btnNext = findViewById(R.id.btnNextUpload);

        btnNext.setOnClickListener(v -> {

            int selectedId = radioGroup.getCheckedRadioButtonId();

            if(selectedId == -1){
                Toast.makeText(this, "Please select a course", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Course Selected", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, UploadDocumentsActivity.class));
            }
        });
    }
}