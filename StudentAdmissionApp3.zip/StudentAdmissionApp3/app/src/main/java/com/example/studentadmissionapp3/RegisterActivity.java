package com.example.studentadmissionapp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    Button btnStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnStart = findViewById(R.id.btnStartRegistration);

        btnStart.setOnClickListener(v ->
                startActivity(new Intent(this, PersonalInfoActivity.class))
        );
    }
}