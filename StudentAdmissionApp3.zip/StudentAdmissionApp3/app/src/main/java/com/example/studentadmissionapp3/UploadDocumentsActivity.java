package com.example.studentadmissionapp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UploadDocumentsActivity extends AppCompatActivity {

    Button btnUploadID, btnUploadCertificate, btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_documents);

        btnUploadID = findViewById(R.id.btnUploadID);
        btnUploadCertificate = findViewById(R.id.btnUploadCertificate);
        btnNext = findViewById(R.id.btnNextDetails);

        btnUploadID.setOnClickListener(v ->
                Toast.makeText(this, "ID Document Selected", Toast.LENGTH_SHORT).show());

        btnUploadCertificate.setOnClickListener(v ->
                Toast.makeText(this, "Certificate Selected", Toast.LENGTH_SHORT).show());

        btnNext.setOnClickListener(v ->
                startActivity(new Intent(this, ViewDetailsActivity.class)));
    }
}