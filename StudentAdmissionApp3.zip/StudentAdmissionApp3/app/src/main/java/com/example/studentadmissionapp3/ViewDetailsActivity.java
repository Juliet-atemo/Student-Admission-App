package com.example.studentadmissionapp3;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ViewDetailsActivity extends AppCompatActivity {

    TextView tvDetails;
    Button btnViewStudents, btnFinalApply;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_details);

        tvDetails = findViewById(R.id.tvDetails);
        btnViewStudents = findViewById(R.id.btnViewStudents);
        btnFinalApply = findViewById(R.id.btnFinalApply);

        db = new DatabaseHelper(this);

        loadDetails();

        // View All Students Button
        btnViewStudents.setOnClickListener(v ->
                startActivity(new Intent(this, ViewStudentsActivity.class))
        );

        // Confirm & Apply Button
        btnFinalApply.setOnClickListener(v ->
                startActivity(new Intent(this, SuccessActivity.class))
        );
    }

    private void loadDetails() {

        Cursor cursor = db.getLatestApplication();

        if (cursor != null && cursor.moveToFirst()) {

            String details =
                    "Full Name: " + cursor.getString(1) + "\n\n" +
                            "Email: " + cursor.getString(2) + "\n\n" +
                            "Phone: " + cursor.getString(3) + "\n\n" +
                            "Date of Birth: " + cursor.getString(4) + "\n\n" +
                            "Gender: " + cursor.getString(5) + "\n\n" +
                            "Residential Address: " + cursor.getString(6) + "\n\n" +
                            "Previous School: " + cursor.getString(7) + "\n\n" +
                            "Course Selected: " + cursor.getString(8);

            tvDetails.setText(details);

        } else {
            tvDetails.setText("No Application Found.");
        }

        if (cursor != null) {
            cursor.close();
        }
    }
}