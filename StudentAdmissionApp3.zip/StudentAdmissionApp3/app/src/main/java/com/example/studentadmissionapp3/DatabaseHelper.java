package com.example.studentadmissionapp3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentAdmission.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // USERS TABLE
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT)");

        // APPLICATIONS TABLE
        db.execSQL("CREATE TABLE applications (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "fullname TEXT," +
                "email TEXT," +
                "phone TEXT," +
                "dob TEXT," +
                "gender TEXT," +
                "address TEXT," +
                "previous_school TEXT," +
                "course TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS applications");
        onCreate(db);
    }

    // =============================
    // REGISTER USER
    // =============================
    public boolean registerUser(String name, String email, String password) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("email", email);
        values.put("password", password);

        long result = db.insert("users", null, values);

        return result != -1;
    }

    // =============================
    // LOGIN USER
    // =============================
    public boolean loginUser(String email, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE email=? AND password=?",
                new String[]{email, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // =============================
    // SAVE APPLICATION
    // =============================
    public boolean saveApplication(String fullname,
                                   String email,
                                   String phone,
                                   String dob,
                                   String gender,
                                   String address,
                                   String previousSchool,
                                   String course) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("fullname", fullname);
        values.put("email", email);
        values.put("phone", phone);
        values.put("dob", dob);
        values.put("gender", gender);
        values.put("address", address);
        values.put("previous_school", previousSchool);
        values.put("course", course);

        long result = db.insert("applications", null, values);

        return result != -1;
    }

    // =============================
    // GET ALL APPLICATIONS
    // =============================
    public Cursor getApplications() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM applications", null);
    }

    // =============================
    // GET LATEST APPLICATION
    // =============================
    public Cursor getLatestApplication() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM applications ORDER BY id DESC LIMIT 1",
                null
        );
    }
}