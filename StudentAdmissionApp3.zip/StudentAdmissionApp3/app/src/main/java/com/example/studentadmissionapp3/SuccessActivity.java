package com.example.studentadmissionapp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SuccessActivity extends AppCompatActivity {

    TextView tvSuccessMessage;
    Button btnGoHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        tvSuccessMessage = findViewById(R.id.tvSuccessMessage);
        btnGoHome = findViewById(R.id.btnGoHome);

        tvSuccessMessage.setText(
                "🎓 Congratulations!\n\n" +
                        "Your application has been submitted successfully.\n\n" +
                        "Our admissions office will contact you soon."
        );

        btnGoHome.setOnClickListener(v -> {
            Intent intent = new Intent(SuccessActivity.this, LandingPageActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }
}