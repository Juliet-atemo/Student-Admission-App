package com.example.studentadmissionapp3;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViewStudentsActivity extends AppCompatActivity {

    TextView tvStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_students);

        tvStudents = findViewById(R.id.tvStudents);

        // Sample data (for assignment purposes)
        tvStudents.setText(
                "1. John Doe - Computer Science\n" +
                        "2. Jane Smith - Business Administration\n" +
                        "3. Michael Johnson - Information Technology\n" +
                        "4. Sarah Williams - Education\n" +
                        "5. David Brown - Nursing"
        );
    }
}