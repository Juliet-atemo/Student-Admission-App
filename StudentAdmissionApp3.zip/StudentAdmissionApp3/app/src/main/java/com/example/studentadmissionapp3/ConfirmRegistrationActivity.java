package com.example.studentadmissionapp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ConfirmRegistrationActivity extends AppCompatActivity {

    TextView tvDetails;
    Button btnFinish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_registration);

        tvDetails = findViewById(R.id.tvDetails);
        btnFinish = findViewById(R.id.btnFinish);

        Intent i = getIntent();

        String details =
                "Name: " + i.getStringExtra("fullname") + "\n" +
                        "Email: " + i.getStringExtra("email") + "\n" +
                        "Phone: " + i.getStringExtra("phone") + "\n" +
                        "DOB: " + i.getStringExtra("dob") + "\n" +
                        "Gender: " + i.getStringExtra("gender") + "\n" +
                        "Address: " + i.getStringExtra("address") + "\n" +
                        "School: " + i.getStringExtra("school") + "\n" +
                        "Documents: " + i.getStringExtra("documents") + "\n" +
                        "Course: " + i.getStringExtra("course");

        tvDetails.setText(details);

        btnFinish.setOnClickListener(v -> {
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        });
    }
}