package com.example.studentadmissionapp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PersonalInfoActivity extends AppCompatActivity {

    EditText etFullName, etEmail, etPhone, etDOB, etAddress, etPreviousSchool;
    Spinner spGender;
    Button btnContinue;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);

        db = new DatabaseHelper(this);

        // INPUT FIELDS
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etDOB = findViewById(R.id.etDOB);
        etAddress = findViewById(R.id.etAddress);
        etPreviousSchool = findViewById(R.id.etPreviousSchool);

        spGender = findViewById(R.id.spGender);
        btnContinue = findViewById(R.id.btnContinue);

        // GENDER OPTIONS
        String[] genderOptions = {"Select Gender", "Male", "Female", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                genderOptions
        );
        spGender.setAdapter(adapter);

        // CONTINUE BUTTON
        btnContinue.setOnClickListener(v -> {

            String gender = spGender.getSelectedItem().toString();

            if(etFullName.getText().toString().isEmpty() ||
                    etEmail.getText().toString().isEmpty() ||
                    etPhone.getText().toString().isEmpty() ||
                    etDOB.getText().toString().isEmpty() ||
                    etAddress.getText().toString().isEmpty() ||
                    etPreviousSchool.getText().toString().isEmpty() ||
                    gender.equals("Select Gender")) {

                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean saved = db.saveApplication(
                    etFullName.getText().toString(),
                    etEmail.getText().toString(),
                    etPhone.getText().toString(),
                    etDOB.getText().toString(),
                    gender,
                    etAddress.getText().toString(),
                    etPreviousSchool.getText().toString(),
                    "Not Selected"
            );

            if(saved){
                Toast.makeText(this, "Information Saved", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, ChooseCourseActivity.class));
            } else {
                Toast.makeText(this, "Error Saving Data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}